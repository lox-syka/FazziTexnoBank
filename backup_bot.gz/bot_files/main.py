import discord
import tarfile
import s
import cards_
import os
import money
import balence
import move
from discord import File
import all_numbers

settings = open('settings.txt', 'r')
list_s = settings.read().split('\n')
if 'true' in list_s[0]:
	development = True
else:
	development = False

print("Development: " + str(development))

class MyClient(discord.Client):
	async def on_ready(self):{
	print(f'"{client.user.name}" Started')
	}

	async def on_message(self, message):
		a = message.content.split(' ')
		author = message.author
		channel = message.channel

		if message.channel.id == s.channel_all: # если канал #участники
			if a[0] == '!баланс':
				try:
					author = message.author
					channel = message.channel
					await balence.get(author, channel)
				except IndexError:
					await message.channel.send(s.error_syntacs)
	
			if a[0] == '!перевод':
				await message.channel.send(f'Ошибка, попросите помощи в переводе у банкира.')
	
			if a[0] == '!список':
				if a[1] == 'карт':
					await all_numbers.main(message)
	
	
				return

		if message.channel.id == s.channel_bankir: # если канал банкир
			if str(s.bankir) in str(author.roles): # если банкир
				if a[0] == '!создать_счёт':
					ban_list = [client.user.id, 235088799074484224, 228537642583588864,]
					try:
						nick = a[1]
						mention = message.mentions[0]
						dis = mention.id
						card_name = a[2]
						if str(dis) in str(ban_list):
							await message.channel.send('Ошибка, `{error.no_created.banned_list}`')
						else:
							await mention.send('Создание счёта.')
							await cards_.create(nick, dis, channel, card_name, mention, discord)

					except IndexError:
						await message.channel.send(s.error_syntacs)
					except discord.errors.Forbidden:
						await message.channel.send('Критическая ошибка, у будующего владельца счёта закрыты личные сообщения в Дискорд, данные отправить не удалось, операция отменена.')

				if a[0] == '!положить':
					try:
						count_money = a[2]
						card_number = a[1]
						channel = message.channel
						await money.add_money(count_money, card_number, channel, client)
					except IndexError:
						await message.channel.send(s.error_syntacs)

				if a[0] == '!снять':
					try:
						count_money = a[2]
						card_number = a[1]
						channel = message.channel
						await money.remove_money(count_money, card_number, channel, client)
					except IndexError:
						await message.channel.send(s.error_syntacs)



		if a[0] == '!debug':
			if '725658167517642753' in str(author.roles):
				if a[1] == 'delete_number':
					card_number = a[2]
					llogs = client.get_channel(s.logs)
					await cards_.remove(card_number, llogs)

				if a[1] == 'move_run':
					await move.move_run('725663873625227294-1','725663873625227294-2', 1)

				if a[1] == 'backup':
					await message.channel.send(file = File('index.txt'))
					tar = tarfile.open("backup.gz", "w:gz")
					tar.add("cards", arcname="cards")
					tar.add("index.txt", arcname="index.txt")
					tar.close()
					await message.channel.send('Бэкап данных успешно создан и отправлен, в архиве backup.gz есть все необходимые файлы для востановления счётов. Бэкап данных бота - `!debug backup_bot`', file = File('backup.gz'))

				if a[1] == 'backup_bot':
					tar = tarfile.open("backup_bot.gz", "w:gz")
					tar.add("./", arcname="bot_files")
					tar.close()
					await message.channel.send(file = File('backup_bot.gz'))

				if a[1] == 'file_read':
					try:
						filee = a[2]
						file_text = open(filee, 'r')
						await message.channel.send('```' + file_text.read() + '```', file = File(filee))
					except discord.errors.HTTPException:
						await message.channel.send('Файл слишком большой для read, файл был просто отправлен!', file = File(filee))
					except IndexError:
						await message.channel.send(s.error_syntacs)
					except FileNotFoundError:
						await message.channel.send('Файл не найден')

				if a[1] == 'listdir':
					try:
						await message.channel.send('```\n' + str(os.listdir(a[2])) + '```')
					except IndexError:
						await message.channel.send(s.error_syntacs)
					except FileNotFoundError:
						await message.channel.send('Деректория не найдена')
					except discord.errors.HTTPException:
						await message.channel.send('Много файлов! сообщение получаеться больше 2000 символов(максимальный размер сообщения)')

				if a[1] == 'user_send':
					men = message.mentions[0]
					kow_list = message.content.split('"')
					await men.send(str(kow_list[1]))


client = MyClient()
if development == False:
	client.run(s.tok)
else:
	client.run('NzI2MDIyNTAzNjI5MzI0Mjk4.XvXQgA.Xft9sufFZnZSqGC_Fm3o8Qy3ybo')