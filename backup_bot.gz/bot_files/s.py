bankir = 725661172040466515
channel_bankir = 725656368131866645
channel_all = 725656308388462623
logs = 726781184285343794

# Название валюты
p = 'п.'

# Ошибки
error_syntacs = 'Ошибка, не верный синтаксис команды!'
error_value = 'Ошибка, Значение какого то аргумента предоставлено в другом формате!\nP.s. Возможно вместо цифры вы написали букву или наоборот.'

debug = 1

tok = 'NzMxNzgwMzkyNTQ5MzUxNDQ0.XwrCqA.soS3zr1nmhvhiyFL5mQyCs2Ibrw'